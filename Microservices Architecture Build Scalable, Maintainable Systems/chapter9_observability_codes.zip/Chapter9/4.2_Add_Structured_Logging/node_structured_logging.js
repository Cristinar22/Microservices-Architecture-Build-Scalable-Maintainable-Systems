const pino = require('pino');
const logger = pino();

logger.info({ event: "order_created", order_id: "A123" });
logger.error({ event: "order_failed", order_id: "A123", error: "timeout" });
