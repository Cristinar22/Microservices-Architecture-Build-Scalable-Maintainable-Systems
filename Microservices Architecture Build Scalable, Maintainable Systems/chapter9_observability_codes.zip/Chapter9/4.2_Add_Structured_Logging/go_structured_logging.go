package main

import (
    "go.uber.org/zap"
)

func main() {
    logger, _ := zap.NewProduction()
    defer logger.Sync()

    logger.Info("order_created", zap.String("order_id", "A123"))
    logger.Error("order_failed", zap.String("order_id", "A123"), zap.Error(err))
}
