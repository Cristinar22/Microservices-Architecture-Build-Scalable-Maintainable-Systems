#!/bin/bash
# Launch the observability stack
docker-compose up -d
