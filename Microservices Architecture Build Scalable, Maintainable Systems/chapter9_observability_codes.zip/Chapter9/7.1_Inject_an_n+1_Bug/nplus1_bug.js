// n+1 query bug example
for (let i = 0; i < orders.length; i++) {
  // Fetch user for each order (slow)
  const user = await getUser(orders[i].userId);
}
