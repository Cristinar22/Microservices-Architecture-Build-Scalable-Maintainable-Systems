package main

import (
    "net/http"
    "log"
)

func main() {
    http.HandleFunc("/posts/42", func(w http.ResponseWriter, r *http.Request) {
        w.WriteHeader(http.StatusOK)
        w.Write([]byte(`{"id":42,"status":"draft"}`))
    })
    log.Fatal(http.ListenAndServe(":8001", nil))
}