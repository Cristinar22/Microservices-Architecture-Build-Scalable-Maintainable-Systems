package main

import (
    "net/http"
    "log"
)

func main() {
    http.HandleFunc("/sessions", func(w http.ResponseWriter, r *http.Request) {
        w.WriteHeader(http.StatusCreated)
        w.Write([]byte(`{"jwt":"placeholder"}`))
    })
    log.Fatal(http.ListenAndServe(":8000", nil))
}