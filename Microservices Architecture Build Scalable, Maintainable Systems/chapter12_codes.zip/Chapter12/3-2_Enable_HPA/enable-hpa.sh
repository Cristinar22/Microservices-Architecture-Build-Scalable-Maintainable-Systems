#!/bin/bash
# Enable Horizontal Pod Autoscaling (HPA)
kubectl autoscale deployment cart-service --cpu-percent=50 --min=1 --max=10

# Check HPA status
kubectl get hpa

# Simulate load
# hey -n 10000 -c 50 http://localhost:30080/
