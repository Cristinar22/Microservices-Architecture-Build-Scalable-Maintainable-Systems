#!/bin/bash
# Install OpenCost for cost tracking
kubectl apply -f https://github.com/opencost/opencost/releases/latest/download/opencost-kubernetes.yaml

# Port-forward to access the dashboard
kubectl port-forward --namespace opencost deployment/opencost 9090
