#!/bin/bash
# Create Keda namespace and install Keda operator
kubectl create namespace keda
kubectl apply -f https://github.com/kedacore/keda/releases/latest/download/keda-operator.yaml
