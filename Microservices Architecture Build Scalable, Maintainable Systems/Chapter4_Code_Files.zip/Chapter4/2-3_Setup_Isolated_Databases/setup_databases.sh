#!/bin/bash
# Start three isolated Postgres databases for Order, Payment, and Inventory
docker run --name order-db -e POSTGRES_PASSWORD=orderpass -d -p 5433:5432 postgres:15
docker run --name payment-db -e POSTGRES_PASSWORD=paypass -d -p 5434:5432 postgres:15
docker run --name inventory-db -e POSTGRES_PASSWORD=invpass -d -p 5435:5432 postgres:15
