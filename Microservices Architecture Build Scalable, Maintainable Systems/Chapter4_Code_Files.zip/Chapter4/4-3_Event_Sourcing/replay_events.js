// Simple event sourcing replay script
const fs = require('fs');

function replayEvents() {
  const events = fs.readFileSync('events.log', 'utf-8')
    .trim().split('\n')
    .map(line => JSON.parse(line));

  const state = {};
  events.forEach(event => {
    switch(event.eventType) {
      case 'OrderCreated':
        state[event.orderId] = {order: event.payload};
        break;
      case 'PaymentReceived':
        state[event.orderId].payment = event.payload;
        break;
      case 'InventoryReserved':
        state[event.orderId].inventory = event.payload;
        break;
    }
  });

  console.log('Rebuilt state:', state);
}

replayEvents();
