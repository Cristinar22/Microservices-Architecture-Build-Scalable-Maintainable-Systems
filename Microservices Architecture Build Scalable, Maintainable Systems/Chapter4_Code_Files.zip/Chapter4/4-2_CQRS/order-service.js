// Order Service: handles commands
const express = require('express');
const app = express();
const EventEmitter = require('events');
const eventBus = new EventEmitter();

app.use(express.json());

app.post('/order', (req, res) => {
  const order = {orderId: Date.now(), ...req.body};
  // Perform business logic...
  eventBus.emit('OrderCreated', order);
  res.json(order);
});

app.listen(5001, () => console.log('Order service on 5001'));

module.exports = eventBus;
