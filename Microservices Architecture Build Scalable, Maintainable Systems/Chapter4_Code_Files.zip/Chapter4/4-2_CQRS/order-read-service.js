// Order Read Service: handles queries
const express = require('express');
const app = express();
const eventBus = require('./order-service'); // in-memory for demo

let orders = [];

eventBus.on('OrderCreated', (order) => {
  orders.push(order);
});

app.get('/orders', (req, res) => {
  res.json(orders);
});

app.listen(5002, () => console.log('Order read service on 5002'));
