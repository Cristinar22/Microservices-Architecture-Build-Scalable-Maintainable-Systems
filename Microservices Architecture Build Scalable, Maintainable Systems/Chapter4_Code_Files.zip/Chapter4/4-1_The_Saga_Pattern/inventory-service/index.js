const express = require('express');
const app = express();
app.use(express.json());

app.post('/reserve', (req, res) => {
  if (Math.random() < 0.8) {
    console.log('Inventory reserved');
    res.json({status: 'reserved'});
  } else {
    console.log('Inventory reservation failed!');
    res.status(500).json({error: 'No stock'});
  }
});

app.listen(4003, () => console.log('Inventory service on 4003'));
