const express = require('express');
const app = express();
app.use(express.json());

app.post('/create', (req, res) => {
  console.log('Order created');
  res.json({orderId: 1});
});

app.post('/cancel', (req, res) => {
  console.log('Order canceled:', req.body.orderId);
  res.json({status: 'cancelled'});
});

app.listen(4001, () => console.log('Order service on 4001'));
