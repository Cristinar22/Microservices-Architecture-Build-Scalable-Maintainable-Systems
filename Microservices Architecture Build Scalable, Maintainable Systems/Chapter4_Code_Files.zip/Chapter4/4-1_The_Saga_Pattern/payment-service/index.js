const express = require('express');
const app = express();
app.use(express.json());

app.post('/charge', (req, res) => {
  if (Math.random() < 0.7) {
    console.log('Payment success');
    res.json({status: 'paid'});
  } else {
    console.log('Payment failed!');
    res.status(500).json({error: 'Payment error'});
  }
});

app.post('/refund', (req, res) => {
  console.log('Payment refunded:', req.body.orderId);
  res.json({status: 'refunded'});
});

app.listen(4002, () => console.log('Payment service on 4002'));
