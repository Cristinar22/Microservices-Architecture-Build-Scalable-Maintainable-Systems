const axios = require('axios');
const fs = require('fs');

async function placeOrderSaga(orderDetails) {
  let orderId;
  try {
    const order = await axios.post('http://localhost:4001/create', orderDetails);
    orderId = order.data.orderId;
    await axios.post('http://localhost:4002/charge', {orderId});
    await axios.post('http://localhost:4003/reserve', {orderId});
    console.log('Order process complete!');
    return {status: 'success', orderId};
  } catch (error) {
    console.log('Saga failed, starting compensation...');
    if (orderId) {
      await axios.post('http://localhost:4001/cancel', {orderId}).catch(()=>{});
      await axios.post('http://localhost:4002/refund', {orderId}).catch(()=>{});
    }
    // Dead-letter log
    fs.appendFileSync('dead-letter.log', JSON.stringify({orderId, error: error.message}) + '\n');
    return {status: 'failed', error: error.message};
  }
}

// Simulate the Saga
placeOrderSaga({customerId: 123, item: "Book"})
  .then(console.log)
  .catch(console.error);
