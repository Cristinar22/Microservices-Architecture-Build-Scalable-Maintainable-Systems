#!/bin/bash
# Build the multi-stage image
docker build -t hello-go:multi .

# Run the Go container
docker run -p 8080:8080 hello-go:multi