#!/bin/bash
# Generate a key pair
cosign generate-key-pair

# Sign the Docker image
cosign sign --key cosign.key yourusername/hello-docker:1.0

# Verify the signature
cosign verify --key cosign.pub yourusername/hello-docker:1.0