#!/bin/bash
# Build the image
docker build -t hello-docker:basic .

# Run the container
docker run -p 3000:3000 hello-docker:basic