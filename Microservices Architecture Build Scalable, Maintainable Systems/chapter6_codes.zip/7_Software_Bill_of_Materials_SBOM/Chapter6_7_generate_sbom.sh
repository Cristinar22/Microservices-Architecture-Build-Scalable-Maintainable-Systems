#!/bin/bash
# Generate SBOM with Docker SBOM command
docker sbom hello-docker:basic

# Or using Syft
syft hello-docker:basic