import io.github.resilience4j.retry.annotation.Retry;
import io.github.resilience4j.timelimiter.annotation.TimeLimiter;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.concurrent.CompletableFuture;

@RestController
public class OrderControllerAsync {

  @Retry(name = "inventoryRetry", fallbackMethod = "inventoryFallback")
  @TimeLimiter(name = "inventoryTL")
  @RateLimiter(name = "inventoryRL")
  @GetMapping("/order")
  public CompletableFuture<String> createOrder() {
    return CompletableFuture.supplyAsync(() -> 
      restTemplate.getForObject("http://inventory-service/stock", String.class)
    );
  }

  public CompletableFuture<String> inventoryFallback(Exception ex) {
    return CompletableFuture.completedFuture("Inventory error: fallback active.");
  }
}