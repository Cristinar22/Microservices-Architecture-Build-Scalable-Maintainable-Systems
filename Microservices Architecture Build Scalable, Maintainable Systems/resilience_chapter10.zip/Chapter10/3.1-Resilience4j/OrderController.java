import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

  @CircuitBreaker(name = "inventoryCB", fallbackMethod = "inventoryFallback")
  @GetMapping("/order")
  public String createOrder() {
    // Simulate call to inventory service
    return restTemplate.getForObject("http://inventory-service/stock", String.class);
  }

  public String inventoryFallback(Exception ex) {
    return "Inventory temporarily unavailable, please try later.";
  }
}