using Polly;
using Polly.CircuitBreaker;
using Polly.Retry;
using System;
using System.Net.Http;

class PollyExample
{
    static void Main()
    {
        var retryPolicy = Policy
          .Handle<HttpRequestException>()
          .WaitAndRetry(3, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));

        var circuitBreakerPolicy = Policy
          .Handle<HttpRequestException>()
          .CircuitBreaker(2, TimeSpan.FromSeconds(10));

        try
        {
            retryPolicy.Execute(() =>
            {
                circuitBreakerPolicy.Execute(() =>
                {
                    // Make HTTP call here
                });
            });
        }
        catch (Exception ex)
        {
            // Fallback logic
        }
    }
}