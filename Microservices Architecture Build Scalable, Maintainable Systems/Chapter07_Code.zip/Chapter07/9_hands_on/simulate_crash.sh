#!/bin/bash
# Simulate a pod crash
kubectl delete pod <one-pod-name>
# View all resources
kubectl get all