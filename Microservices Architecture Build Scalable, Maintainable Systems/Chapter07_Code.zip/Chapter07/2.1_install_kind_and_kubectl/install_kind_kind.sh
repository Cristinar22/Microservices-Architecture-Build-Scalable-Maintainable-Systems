#!/bin/bash
# Install kind
go install sigs.k8s.io/kind@v0.22.0
# On Mac:
# brew install kind