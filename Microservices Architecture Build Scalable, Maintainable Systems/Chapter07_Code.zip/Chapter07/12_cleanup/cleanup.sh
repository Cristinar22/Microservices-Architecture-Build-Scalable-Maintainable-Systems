#!/bin/bash
# Delete cluster and prune docker
kind delete cluster --name shop
docker system prune -af