#!/bin/bash
# Create catalog secret
kubectl create secret generic catalog-secret --from-literal=API_KEY=my-secret-value