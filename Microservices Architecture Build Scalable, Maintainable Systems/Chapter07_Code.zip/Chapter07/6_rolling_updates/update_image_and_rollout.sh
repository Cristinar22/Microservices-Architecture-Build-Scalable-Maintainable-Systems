#!/bin/bash
# Update image to 1.1 and rollout
# Update catalog-deployment.yaml: image: yourdockerhub/catalog:1.1
kubectl apply -f catalog-deployment.yaml
kubectl rollout status deployment/catalog
# Rollback if needed
kubectl rollout undo deployment/catalog