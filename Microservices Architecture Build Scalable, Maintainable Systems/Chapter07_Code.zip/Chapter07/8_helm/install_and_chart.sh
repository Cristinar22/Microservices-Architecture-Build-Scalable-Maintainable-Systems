#!/bin/bash
# Install Helm (see official guide)
# Scaffold a chart
helm create shop
cd shop
# Edit values.yaml and templates as needed