#!/bin/bash
# Deploy with Helm
helm install shop ./shop
# Upgrade
helm upgrade shop ./shop