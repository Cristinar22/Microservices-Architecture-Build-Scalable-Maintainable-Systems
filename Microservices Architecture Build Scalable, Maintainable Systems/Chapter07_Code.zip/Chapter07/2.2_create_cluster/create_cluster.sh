#!/bin/bash
# Create kind cluster
kind create cluster --name shop
kubectl cluster-info --context kind-shop
# Test cluster
kubectl get nodes
kubectl get pods -A