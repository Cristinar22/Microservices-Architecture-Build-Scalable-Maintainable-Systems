#!/bin/bash
# Apply catalog deployment
kubectl apply -f catalog-deployment.yaml
kubectl get deployments
kubectl get pods