#!/bin/bash
# Test catalog service
curl localhost:30080/health