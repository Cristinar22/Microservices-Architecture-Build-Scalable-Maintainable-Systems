import json
from kafka import KafkaConsumer
import smtplib

consumer = KafkaConsumer('sensor-data',
                         bootstrap_servers='localhost:9092',
                         value_deserializer=lambda m: json.loads(m.decode('utf-8')))

def send_email_alert(data):
    # Placeholder for email alert logic
    print(f"ALERT! Sensor reading critical: {data}")

for msg in consumer:
    data = msg.value
    if data['temperature'] > 75.0:
        print(f"Warning: High temperature detected {data}")
        send_email_alert(data)
    else:
        print(f"Normal reading: {data}")
