import json
from kafka import KafkaConsumer

consumer = KafkaConsumer('price-updates',
                         bootstrap_servers='localhost:9092',
                         value_deserializer=lambda m: json.loads(m.decode('utf-8')))

for msg in consumer:
    event = msg.value
    # Update database or cache here
    print(f"Updated price for product {event['product_id']}: {event['price']}")
