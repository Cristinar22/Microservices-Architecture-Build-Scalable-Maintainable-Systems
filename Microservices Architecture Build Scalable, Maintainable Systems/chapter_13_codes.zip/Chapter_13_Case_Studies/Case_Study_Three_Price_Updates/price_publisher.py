import time
import random
from kafka import KafkaProducer
import json

producer = KafkaProducer(bootstrap_servers='localhost:9092',
                         value_serializer=lambda v: json.dumps(v).encode('utf-8'))

def publish_price_updates():
    while True:
        event = {
            'product_id': random.randint(1, 100),
            'price': round(random.uniform(10.0, 500.0), 2)
        }
        producer.send('price-updates', value=event)
        print(f"Published: {event}")
        time.sleep(2)

if __name__ == "__main__":
    publish_price_updates()
