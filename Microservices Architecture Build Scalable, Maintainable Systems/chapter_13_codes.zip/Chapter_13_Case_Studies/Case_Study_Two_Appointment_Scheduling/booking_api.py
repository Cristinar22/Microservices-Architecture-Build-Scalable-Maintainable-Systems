from flask import Flask, request, jsonify
import jwt
import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'

def token_required(f):
    def wrapper(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token is missing'}), 401
        try:
            jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
        except:
            return jsonify({'message': 'Token is invalid'}), 401
        return f(*args, **kwargs)
    return wrapper

@app.route('/login')
def login():
    token = jwt.encode({'user': 'test', 'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=30)},
                       app.config['SECRET_KEY'], algorithm='HS256')
    return jsonify({'token': token})

@app.route('/book', methods=['POST'])
@token_required
def book_appointment():
    data = request.json
    # Save booking logic here
    return jsonify({'message': 'Appointment booked', 'data': data})

if __name__ == '__main__':
    app.run(debug=True)
