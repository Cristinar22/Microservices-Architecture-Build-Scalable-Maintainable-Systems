from flask import Flask, request
import json

app = Flask(__name__)

@app.route('/notify', methods=['POST'])
def notify():
    event = request.json
    # Send notification logic, no personal info in event
    print(f"Notification: {event}")
    return '', 204

if __name__ == '__main__':
    app.run(port=5001, debug=True)
