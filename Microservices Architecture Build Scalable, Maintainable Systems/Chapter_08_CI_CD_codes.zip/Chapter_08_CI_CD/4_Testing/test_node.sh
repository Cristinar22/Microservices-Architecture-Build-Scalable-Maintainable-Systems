#!/bin/bash
# Install Jest and run tests
npm install --save-dev jest

# Add test script in package.json:
# {
#   "scripts": {
#     "test": "jest"
#   }
# }
npm test
