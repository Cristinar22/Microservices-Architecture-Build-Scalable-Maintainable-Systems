#!/bin/bash
# Install Trivy (per official docs) and scan image
trivy image yourusername/myapp:latest
