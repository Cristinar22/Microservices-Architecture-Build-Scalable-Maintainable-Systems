#!/bin/bash
# Install and initialize ESLint
npm install eslint --save-dev
npx eslint --init

# Add lint script to package.json
# {
#   "scripts": {
#     "lint": "eslint ."
#   }
# }
npm run lint
