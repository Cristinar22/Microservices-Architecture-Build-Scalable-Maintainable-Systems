#!/bin/bash
# Build Docker image
docker build -t yourusername/myapp:latest .

# Run Docker container
docker run -p 3000:3000 yourusername/myapp:latest
