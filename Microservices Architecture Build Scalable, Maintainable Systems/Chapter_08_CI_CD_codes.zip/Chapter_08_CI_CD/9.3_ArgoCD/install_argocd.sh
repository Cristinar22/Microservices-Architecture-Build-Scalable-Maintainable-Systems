#!/bin/bash
# Install Argo CD in your Kubernetes cluster
kubectl create namespace argocd
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# Port-forward Argo CD server
kubectl port-forward svc/argocd-server -n argocd 8080:443

# Access Argo CD UI at https://localhost:8080
