#!/bin/bash
curl http://localhost:8080/realms/microservices-demo/.well-known/openid-configuration