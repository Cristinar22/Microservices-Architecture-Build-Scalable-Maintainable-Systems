const fs = require('fs');
const https = require('https');
const express = require('express');

const app = express();

const options = {
  key: fs.readFileSync('key.pem'),
  cert: fs.readFileSync('cert.pem'),
  ca: [fs.readFileSync('other-service-cert.pem')],
  requestCert: true,
  rejectUnauthorized: true,
};

https.createServer(options, app).listen(3001, () => {
  console.log('Order service (mTLS) on 3001');
});