#!/bin/bash
# Store secret
curl --header "X-Vault-Token: root" --request POST \
  --data '{"data": {"dbpass": "mypassword"}}' \
  http://localhost:8200/v1/secret/data/order-db

# Retrieve secret
curl --header "X-Vault-Token: root" http://localhost:8200/v1/secret/data/order-db