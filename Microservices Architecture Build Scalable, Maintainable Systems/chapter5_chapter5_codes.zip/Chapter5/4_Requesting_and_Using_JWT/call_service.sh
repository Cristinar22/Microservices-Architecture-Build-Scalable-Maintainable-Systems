#!/bin/bash
curl -H "Authorization: Bearer <access_token>" http://localhost:3001/order