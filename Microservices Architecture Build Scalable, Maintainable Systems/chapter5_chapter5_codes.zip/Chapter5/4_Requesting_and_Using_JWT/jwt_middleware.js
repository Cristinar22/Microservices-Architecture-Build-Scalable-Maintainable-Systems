const jwt = require('jsonwebtoken');
const KEYCLOAK_PUBLIC_KEY = /* fetch from Keycloak or .well-known jwks */;
app.use((req, res, next) => {
  const auth = req.headers['authorization'];
  if (!auth) return res.status(401).send('No token!');
  const token = auth.split(' ')[1];
  jwt.verify(token, KEYCLOAK_PUBLIC_KEY, (err, decoded) => {
    if (err) return res.status(403).send('Invalid token');
    req.user = decoded;
    next();
  });
});