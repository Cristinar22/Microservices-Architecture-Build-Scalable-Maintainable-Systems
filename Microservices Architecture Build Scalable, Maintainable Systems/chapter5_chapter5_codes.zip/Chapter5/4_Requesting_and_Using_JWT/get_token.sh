#!/bin/bash
curl -X POST \
  http://localhost:8080/realms/microservices-demo/protocol/openid-connect/token \
  -d "client_id=order-service" \
  -d "grant_type=password" \
  -d "username=testuser" \
  -d "password=<your-password>" \
  -d "client_secret=<client-secret-if-shown>" \
  -d "scope=openid"