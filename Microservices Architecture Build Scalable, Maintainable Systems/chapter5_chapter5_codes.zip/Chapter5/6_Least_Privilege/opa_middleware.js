const axios = require('axios');
async function checkPolicy(req) {
  const input = {
    method: req.method,
    path: req.path.split('/').slice(1),
    user_role: req.user.role,
  };
  const res = await axios.post('http://localhost:8181/v1/data/httpapi/authz/allow', {input});
  return res.data.result === true;
}
// Use checkPolicy(req) before handling requests