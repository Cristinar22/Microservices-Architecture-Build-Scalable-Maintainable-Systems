#!/bin/bash
docker run -d --name opa -p 8181:8181 openpolicyagent/opa:latest run --server