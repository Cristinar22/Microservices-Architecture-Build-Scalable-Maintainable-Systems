#!/bin/bash
# Chapter 3 - Section 5: Stubbing the Three Services

# Directory structure
tree shop \
  |-- catalog-service
  |-- cart-service
  `-- order-service

# Catalog Service Setup
cd shop/catalog-service
npm init -y
npm install express
echo "const app=require('express')(); app.get('/health',(_,r)=>r.send('ok')); app.listen(3001);" > index.js

# Cart Service Setup
cd ../cart-service
npm init -y
npm install express
echo "const app=require('express')(); app.get('/health',(_,r)=>r.send('ok')); app.listen(3002);" > index.js

# Order Service Setup
cd ../order-service
npm init -y
npm install express
echo "const app=require('express')(); app.get('/health',(_,r)=>r.send('ok')); app.listen(3003);" > index.js
