#!/usr/bin/env bash
# Setup analytics-service
mkdir analytics-service && cd analytics-service
npm init -y
npm install kafkajs
