// analytics-service.js
const { Kafka } = require('kafkajs');

const kafka = new Kafka({ brokers: ['localhost:9092'] });
const consumer = kafka.consumer({ groupId: 'analytics-group' });

let revenueByMinute = {};

async function run() {
  await consumer.connect();
  await consumer.subscribe({ topic: 'cart-events', fromBeginning: true });

  await consumer.run({
    eachMessage: async ({ message }) => {
      const event = JSON.parse(message.value.toString());
      const minute = Math.floor(event.checkedOutAt / 60000);
      if (!revenueByMinute[minute]) revenueByMinute[minute] = 0;
      revenueByMinute[minute] += event.totalAmount;
      console.log(`Revenue at ${new Date(minute * 60000).toISOString()}: $${revenueByMinute[minute]}`);
    }
  });
}

run();
