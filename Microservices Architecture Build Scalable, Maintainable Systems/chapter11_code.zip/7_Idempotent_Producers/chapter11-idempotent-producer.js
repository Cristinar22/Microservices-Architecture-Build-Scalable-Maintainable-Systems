// idempotent-producer.js
const { Kafka } = require('kafkajs');
const kafka = new Kafka({ brokers: ['localhost:9092'] });

// Idempotent producer configuration
const producer = kafka.producer({ idempotent: true });

// Use this producer to send messages with exactly-once semantics
