#!/usr/bin/env bash
# Start Kafka and Zookeeper
docker-compose up -d

# Verify services are running
docker ps
