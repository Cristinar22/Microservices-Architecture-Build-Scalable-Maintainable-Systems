#!/usr/bin/env bash
# Install KafkaJS client
npm install kafkajs
