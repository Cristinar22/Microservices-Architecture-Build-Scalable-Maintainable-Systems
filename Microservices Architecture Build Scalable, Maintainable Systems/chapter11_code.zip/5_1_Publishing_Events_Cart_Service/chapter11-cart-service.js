// cart-service.js
const { Kafka } = require('kafkajs');

const kafka = new Kafka({ brokers: ['localhost:9092'] });
const producer = kafka.producer();

async function publishCartCheckedOut(cartId, totalAmount) {
  await producer.connect();
  await producer.send({
    topic: 'cart-events',
    messages: [
      {
        key: String(cartId),
        value: JSON.stringify({ cartId, totalAmount, checkedOutAt: Date.now() })
      }
    ]
  });
  await producer.disconnect();
}

// Express checkout endpoint
app.post('/cart/checkout', async (req, res) => {
  const { cartId, totalAmount } = req.body;
  // ... business logic to complete checkout ...
  await publishCartCheckedOut(cartId, totalAmount);
  res.status(200).json({ status: 'ok' });
});
