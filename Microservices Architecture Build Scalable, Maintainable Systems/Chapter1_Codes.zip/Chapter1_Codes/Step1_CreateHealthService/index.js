// index.js
const express = require('express');
const app = express();
app.get('/health', (_, res) => res.json({ status: 'UP-from-micro' }));
app.listen(process.env.PORT || 3000, () =>
  console.log('Health service running'));
